package testes;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Matchers.isA;

import org.junit.Before;
import org.junit.Test;

import codigo.CaixaEletronico;
import codigo.ContaCorrente;
import codigo.Hardware;
import codigo.ServicoRemoto;
import codigo.hardwareException;

public class Testes {

	ContaCorrente c1 = new ContaCorrente("123", 100, 0);
	
	Hardware hardware = mock(Hardware.class);
	ServicoRemoto servicoRemoto = mock(ServicoRemoto.class);
	
	CaixaEletronico caixaEletronico = new CaixaEletronico(hardware, servicoRemoto);
	
	@Before
	public void setUp() throws hardwareException{
		when(hardware.pegarNumeroDaContaCartao()).thenReturn("123");
		when(servicoRemoto.recuperarConta("123")).thenReturn(c1);
		
		caixaEletronico.logar();
	}
	
	@Test
	public void testeLogar() throws hardwareException{
		
		assertEquals(caixaEletronico.ccLogada, c1);
		
	}
	
	@Test
	public void testeSacarDepositarSaldo() {
		
		caixaEletronico.sacar(20);
		assertEquals(80, caixaEletronico.ccLogada.saldo, 0);
		assertEquals("O saldo dispon�vel � R$" + c1.saldo +  ". \n", caixaEletronico.saldo());
		
		caixaEletronico.depositar(30);
		assertEquals(30, caixaEletronico.ccLogada.saldoPendente, 0);
		assertEquals("O saldo dispon�vel � R$" + c1.saldo +  ". \nTotal de dep�sitos a conferir: R$"
					 + c1.saldoPendente +".", caixaEletronico.saldo());
	}
	
	@Test
	public void testeNumeroDeChamadaSistemaRemoto(){
		
		caixaEletronico.sacar(20);
		caixaEletronico.depositar(30);
		caixaEletronico.sacar(10);
		caixaEletronico.sacar(5);
		caixaEletronico.depositar(10);
		
		assertEquals(65, caixaEletronico.ccLogada.saldo, 0);
		assertEquals(40, caixaEletronico.ccLogada.saldoPendente, 0);
		verify(servicoRemoto,times(5)).persistirConta(isA(ContaCorrente.class));
		
	}
	
	@Test
	public void testeNumeroDeDepositosPendentes(){
		
		caixaEletronico.sacar(20);
		caixaEletronico.depositar(30);
		caixaEletronico.depositar(10);
		caixaEletronico.sacar(5);
		caixaEletronico.depositar(10);
		
		assertEquals(75, caixaEletronico.ccLogada.saldo, 0);
		assertEquals(50, caixaEletronico.ccLogada.saldoPendente, 0);
		assertEquals(3, caixaEletronico.ccLogada.depositosPendentes);
		
	}
	
	@Test
	public void testeDeSaqueSemFundo() throws hardwareException{
		assertEquals("Saldo insuficiente", caixaEletronico.sacar(120));
		assertEquals(100, caixaEletronico.ccLogada.saldo, 0);
		assertEquals("Retire seu dinheiro", caixaEletronico.sacar(20));
		assertEquals(80, caixaEletronico.ccLogada.saldo, 0);
		assertEquals("Saldo insuficiente", caixaEletronico.sacar(90));
		assertEquals(80, caixaEletronico.ccLogada.saldo, 0);
		assertEquals("Retire seu dinheiro", caixaEletronico.sacar(10));
		assertEquals(70, caixaEletronico.ccLogada.saldo, 0);
		assertEquals("Retire seu dinheiro", caixaEletronico.sacar(50));
		assertEquals(20, caixaEletronico.ccLogada.saldo, 0);
		
		verify(hardware,times(3)).entregarDinheiro();
		
	}
	
	@Test
	public void testeFalhaHardware() throws hardwareException{
		
		doThrow(new hardwareException()).when(hardware).entregarDinheiro();
		assertEquals("Erro de mau funcionamento do Hardware", caixaEletronico.sacar(20));	
		
	}

}
