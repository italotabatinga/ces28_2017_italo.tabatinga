package codigo;

public interface ServicoRemoto {
	
	public ContaCorrente recuperarConta(String num);
	public void persistirConta(ContaCorrente c);
	
}
