package codigo;

public class ContaCorrente {
	
	String numero;
	public double saldo = 0;
	public double saldoPendente = 0;
	public int depositosPendentes = 0;
	
	public ContaCorrente(String numero, double saldo, double saldoPendente){
		this.numero = numero;
		this.saldo = saldo;
		this.saldoPendente = saldoPendente;
	}
	
}
