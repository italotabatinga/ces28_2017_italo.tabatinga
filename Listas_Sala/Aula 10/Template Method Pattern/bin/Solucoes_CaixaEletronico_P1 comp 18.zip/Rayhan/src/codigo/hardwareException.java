package codigo;

@SuppressWarnings("serial")
public class hardwareException extends Throwable {
	String message = "Erro de mau funcionamento do Hardware";
}
