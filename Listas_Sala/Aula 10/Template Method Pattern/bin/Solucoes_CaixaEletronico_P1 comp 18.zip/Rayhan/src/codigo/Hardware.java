package codigo;

public interface Hardware {
	
	public String pegarNumeroDaContaCartao() throws hardwareException;
	public void entregarDinheiro()  throws hardwareException; 
	public void lerEnvelope()  throws hardwareException; 

}
