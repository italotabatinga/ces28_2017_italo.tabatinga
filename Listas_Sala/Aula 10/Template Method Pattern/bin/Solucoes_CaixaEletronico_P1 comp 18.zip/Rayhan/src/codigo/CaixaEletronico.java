package codigo;

public class CaixaEletronico {
	
	private Hardware hardware;
	private ServicoRemoto servicoRemoto;
	
	public ContaCorrente ccLogada;
	
	public CaixaEletronico(Hardware hardware, ServicoRemoto servicoRemoto){
		
		this.hardware = hardware;
		this.servicoRemoto = servicoRemoto;
		
	}
	
	public String logar(){
		
		try {
			ccLogada = servicoRemoto.recuperarConta(hardware.pegarNumeroDaContaCartao());
			return "Usu�rio Autenticado";
		} catch (hardwareException e) {
			return e.message;
		} catch (Exception e2) {
			return "N�o foi poss�vel autenticar o usu�rio";
		}
		
		
	}
	
	public String sacar(double saque){
		
		try {
			if(saque > ccLogada.saldo){
				return "Saldo insuficiente";
			}
			
			hardware.entregarDinheiro();
			ccLogada.saldo = ccLogada.saldo - saque;
			servicoRemoto.persistirConta(ccLogada);
			return "Retire seu dinheiro";
		} catch (hardwareException e) {
			return e.message;
		}
		
	}
	
	public String depositar(double deposito){
		
		try {
			hardware.lerEnvelope();
			ccLogada.depositosPendentes++;
			ccLogada.saldoPendente = ccLogada.saldoPendente + deposito;
			servicoRemoto.persistirConta(ccLogada);
			return "Dep�sito recebido com sucesso";
		} catch (hardwareException e) {
			return e.message;
		}
		
	}
	
	public String saldo(){
		
		if(ccLogada.saldoPendente == 0){
			return "O saldo dispon�vel � R$" + ccLogada.saldo +  ". \n" ;
		}
		
		return "O saldo dispon�vel � R$" + ccLogada.saldo +  ". \nTotal de dep�sitos a conferir: R$" + ccLogada.saldoPendente +"." ;
	}
	
}
