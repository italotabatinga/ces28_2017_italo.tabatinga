package codigo;

public interface Hardware {
	public String pegarNumeroDaContaCartao() throws HardwareFailureException;
	public void entregarDinheiro() throws HardwareFailureException;
	public void lerEnvelope() throws HardwareFailureException;
}
