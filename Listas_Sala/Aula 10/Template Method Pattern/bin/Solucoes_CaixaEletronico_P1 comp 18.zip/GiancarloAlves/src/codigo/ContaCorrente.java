package codigo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ContaCorrente {

	private ArrayList<Deposito> _depositosPendentes;
	private long _saldoCentavos;
	
	public ContaCorrente(long saldoCentavos) {
		_depositosPendentes = new ArrayList<Deposito>();
		_saldoCentavos = saldoCentavos;
	}
	
	public long getSaldoCentavos(){
		return _saldoCentavos;
	}
	
	public List<Deposito> getDepositosPendentes(){
		return Collections.unmodifiableList(_depositosPendentes);
	}
	
	public void sacar(long valorCentavos){
		_saldoCentavos-=valorCentavos;
	}

	public void depositar(Deposito deposito) {
		_depositosPendentes.add(deposito);
	}
	
	public int numeroDepositosPendentes(){
		return _depositosPendentes.size();
	}

}
