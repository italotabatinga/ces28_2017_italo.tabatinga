package codigo;

public class Deposito {

	private long _valorCentavos;
	
	public Deposito(long valorCentavos){
		_valorCentavos=valorCentavos;
	}
	
	public long getValor(){
		return _valorCentavos;
	}
	
	public void setValor(long valor){
		_valorCentavos=valor;
	}
}
