package codigo;

import java.util.List;

public class CaixaEletronico {

	private ServicoRemoto _servicoRemoto;
	private Hardware _hardware;
	private ContaCorrente _contaCorrente;
	
	public CaixaEletronico(ServicoRemoto servicoRemoto, Hardware hardware) {
		_servicoRemoto=servicoRemoto;
		_hardware=hardware;
	}
	
	public String logar(){
		try {
			String numeroContaString;
			numeroContaString = _hardware.pegarNumeroDaContaCartao();
			int numeroConta = Integer.parseInt(numeroContaString);
			_contaCorrente = _servicoRemoto.recuperarConta(numeroConta);
			if(_contaCorrente==null)
				return "N�o foi poss�vel autenticar o usu�rio";
			return "Usu�rio Autenticado";
		} catch (HardwareFailureException e) {
			return "N�o foi poss�vel autenticar o usu�rio";
		}
	}
	
	public String saldo(){
		String mensagem="";
		
		long saldo = _contaCorrente.getSaldoCentavos();
		long saldoReaisInteiro = saldo/100;
		long saldoCentavos = saldo % 100;
		mensagem+="O saldo dispon�vel � R$"+saldoReaisInteiro+","+saldoCentavos+". \n";
		
		List<Deposito> depositosPendentes = _contaCorrente.getDepositosPendentes();
		if(!depositosPendentes.isEmpty()){
			mensagem+="Total de dep�sitos a conferir: R$";
			long totalDepositos=0;
			for(Deposito deposito : depositosPendentes)
				totalDepositos+=deposito.getValor();
			long totalDepositosInteiro = totalDepositos/100;
			long totalDepositosCentavos = totalDepositos%100;
			mensagem+=totalDepositosInteiro+","+totalDepositosCentavos+".";
		}
		
		return mensagem;
	}
	
	public String sacar(long valorCentavos){
		long saldoCentavos = _contaCorrente.getSaldoCentavos();
		if(saldoCentavos>=valorCentavos){
			try{
				_hardware.entregarDinheiro();
				_contaCorrente.sacar(valorCentavos);
				_servicoRemoto.persistirConta(_contaCorrente);
				return "Retire seu dinheiro";
			}
			// Poderia lan�ar a exce��o para cima do caixa eletr�nico, mas preferi
			// tratar no pr�prio caixa eletr�nico para evitar expor informa��es 
			// indesejadas sobre o funcionamento de Hardware, mantendo assim certa seguran�a.
			catch(HardwareFailureException e){
				return "N�o foi poss�vel completar a opera��o. V� a outro caixa.";
			}
		}
		else return "Saldo insuficiente";
	}
	
	public String depositar(long valorCentavos){
		Deposito deposito = new Deposito(valorCentavos);
		try{
			_hardware.lerEnvelope();
			_contaCorrente.depositar(deposito);
			_servicoRemoto.persistirConta(_contaCorrente);
			return "Dep�sito recebido com sucesso";
		}
		// Poderia lan�ar a exce��o para cima do caixa eletr�nico, mas preferi
		// tratar no pr�prio caixa eletr�nico para evitar expor informa��es 
		// indesejadas sobre o funcionamento de Hardware, mantendo assim certa seguran�a.
		catch(HardwareFailureException e){
			return "N�o foi poss�vel completar a opera��o. V� a outro caixa.";
		}
	}
}
