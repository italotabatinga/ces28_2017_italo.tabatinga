package codigo;

public class HardwareFailureException extends Exception {

	public HardwareFailureException(){
		super();
	}
}
