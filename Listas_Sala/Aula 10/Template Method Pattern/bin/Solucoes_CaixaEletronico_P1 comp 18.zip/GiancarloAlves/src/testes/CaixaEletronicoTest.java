package testes;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import codigo.CaixaEletronico;
import codigo.ContaCorrente;
import codigo.Hardware;
import codigo.HardwareFailureException;
import codigo.ServicoRemoto;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.doThrow;

public class CaixaEletronicoTest {

	ContaCorrente _conta1;
	ContaCorrente _conta2;
	Hardware _hardware;
	ServicoRemoto _servicoRemoto;
	CaixaEletronico _caixa;
	
	@Before
	public void setUp() throws HardwareFailureException{
		_conta1 = new ContaCorrente(100000); // 1000 reais
		_conta2 = new ContaCorrente(1000000); // 10000 reais
		_hardware = mock(Hardware.class);
		_servicoRemoto = mock(ServicoRemoto.class);
		when(_hardware.pegarNumeroDaContaCartao()).thenReturn("1234");
		when(_servicoRemoto.recuperarConta(1234)).thenReturn(_conta1);
		
		_caixa = new CaixaEletronico(_servicoRemoto, _hardware);
		_caixa.logar();
	}
	
	@Test
	public void testContaNula(){
		when(_servicoRemoto.recuperarConta(1234)).thenReturn(null);
		assertEquals("N�o foi poss�vel autenticar o usu�rio",_caixa.logar());	
	}
	
	@Test(expected=NullPointerException.class)
	public void testLancaErroSeNaoEstiverLogado(){
		when(_servicoRemoto.recuperarConta(1234)).thenReturn(null);
		_caixa.logar();
		_caixa.depositar(1000);
	}
	
	
	@Test
	public void testSaldo() {
		assertEquals("O saldo dispon�vel � R$1000,0. \n", _caixa.saldo());
		when(_servicoRemoto.recuperarConta(1234)).thenReturn(_conta2);
		
		_caixa.logar();
		assertEquals("O saldo dispon�vel � R$10000,0. \n", _caixa.saldo());
	}
	
	@Test
	public void testDeposito(){
		assertEquals("Dep�sito recebido com sucesso", _caixa.depositar(10000));
		assertEquals("O saldo dispon�vel � R$1000,0. \nTotal de dep�sitos a conferir: R$100,0.", _caixa.saldo());
	}
	
	@Test
	public void testSacar() {
		assertEquals("Retire seu dinheiro",_caixa.sacar(10000));
		assertEquals("O saldo dispon�vel � R$900,0. \n", _caixa.saldo());
	}
	
	@Test
	public void testChamadasServicoCorretas(){
		_caixa.depositar(100);
		_caixa.depositar(200);
		_caixa.depositar(1000);
		_caixa.sacar(2000);
		_caixa.sacar(100);
		
		verify(_servicoRemoto, times(5)).persistirConta(_conta1);
		verify(_servicoRemoto, times(1)).recuperarConta(1234);
		_caixa.logar();
		verify(_servicoRemoto, times(2)).recuperarConta(1234);
		
		try {
			verify(_hardware, times(3)).lerEnvelope();
		} catch (HardwareFailureException e) {
			fail();
		}
		
		try {
			verify(_hardware, times(2)).entregarDinheiro();
		} catch (HardwareFailureException e) {
			fail();
		}
		
	}
	
	@Test
	public void testChamadasHardwareCorretas(){
		_caixa.depositar(100);
		_caixa.depositar(200);
		_caixa.depositar(1000);
		_caixa.sacar(2000);
		_caixa.sacar(100);
		
		_caixa.logar();
		try {
			verify(_hardware, times(3)).lerEnvelope();
			verify(_hardware, times(2)).entregarDinheiro();
			verify(_hardware, times(2)).pegarNumeroDaContaCartao();
		} catch (HardwareFailureException e) {
			fail();
		}
	}
	
	@Test
	public void testSaqueSemFundo(){
		_caixa.depositar(1000000000);
		assertEquals("Saldo insuficiente", _caixa.sacar(1000000));
		try {
			verify(_hardware, never()).entregarDinheiro();
		} catch (HardwareFailureException e) {
			fail();
		}
		assertEquals("O saldo dispon�vel � R$1000,0. \nTotal de dep�sitos a conferir: R$10000000,0.", _caixa.saldo());
		_caixa.sacar(1000);
		_caixa.depositar(1000);
		try {
			verify(_hardware, times(1)).entregarDinheiro();
			verify(_hardware, times(2)).lerEnvelope();
		} catch (HardwareFailureException e) {
			fail();
		}
	}
	
	@Test
	public void testErroNoHardwareLogar() throws HardwareFailureException{
		when(_hardware.pegarNumeroDaContaCartao()).thenThrow(new HardwareFailureException());
		assertEquals("N�o foi poss�vel autenticar o usu�rio", _caixa.logar());
	}
	
	
	@Test
	public void testErroNoHardwareDepositoSaque() throws HardwareFailureException{
		doThrow(new HardwareFailureException()).when(_hardware).lerEnvelope();
		assertEquals("N�o foi poss�vel completar a opera��o. V� a outro caixa.", _caixa.depositar(100));
		
		doThrow(new HardwareFailureException()).when(_hardware).entregarDinheiro();
		assertEquals("N�o foi poss�vel completar a opera��o. V� a outro caixa.", _caixa.sacar(100));
		
		verify(_servicoRemoto, never()).persistirConta(_conta1);
	}
	
}
