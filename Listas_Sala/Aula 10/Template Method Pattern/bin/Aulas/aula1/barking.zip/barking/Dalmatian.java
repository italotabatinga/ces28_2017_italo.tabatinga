
public class Dalmatian extends Dog {

	public void printWhoIam(){
		System.out.println("I am a Dalmatian");
	}
	
}
