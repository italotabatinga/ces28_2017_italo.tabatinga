
public class Barking {
	String bark ( Dog d ){
		return "arf";
	}
	// overloads bark
	String bark ( Dalmatian d ){
		return "woof";
	}
	
	// estas funcoes eh so pra mostrar que d ainda pode ser um dalmatian
	// o ponto eh qual METODO de Barking eh chamado.
	String sayWhoYouAreAndBark( Dog d) {
		d.printWhoIam();
		return "arf";
	}
	String sayWhoYouAreAndBark( Dalmatian d) {
		d.printWhoIam();
		return "woof";
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	  System.out.println( "Parte 1: Qual metodo eh chamado?" );
      Dog dog = new Dalmatian();
      Barking aBarking = new Barking( );
      System.out.println( aBarking.bark( dog ));
      System.out.println( aBarking.bark( new Dalmatian()) );
            
      /*// depois de executar a parte I, uncomment here
      System.out.println( "\n\nParte II: Who I am test " );
      dog.printWhoIam();
      System.out.println( aBarking.sayWhoYouAreAndBark(dog));
      System.out.println( "\n -----" );
      // e mostrar que casting ainda funciona!
      System.out.println( aBarking.sayWhoYouAreAndBark((Dalmatian)dog));
      */
      
      /*
      // after part II, try the following code
      System.out.println( "\n\nParte III: o que acontece? " );
      Dalmatian fakedalm = (Dalmatian)new Dog();
      System.out.println( aBarking.bark( fakedalm ));
      */
      
	}//main()
}//class Barking
